from .generator import Captcha, CaptchaGenerator


__all__ = ("Captcha", "CaptchaGenerator")
