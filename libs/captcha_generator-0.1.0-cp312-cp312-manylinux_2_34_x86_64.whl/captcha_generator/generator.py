from dataclasses import dataclass
from os import PathLike
from pathlib import Path
from typing import Literal

from ril import Image, Pixel

from .captcha_generator import RustGenerator


@dataclass
class Captcha:
    correct_emoji: str
    emojis: list[str]
    image: bytes


class CaptchaGenerator:
    def __init__(
        self,
        emojis_path: str | PathLike,
        emojis_format: Literal["png", "jpg"] = "png",
        num_emojis: int = 5,
        gap: int = 10,
        sizes: tuple[int, int] = (550, 180),
    ):
        if isinstance(emojis_path, str):
            emojis_path = Path(emojis_path)

        self.generator = RustGenerator(emojis_path, emojis_format)
        self.emojis = {
            emoji: Image.from_bytes(data) for emoji, data in self.generator.emoji_map.items()
        }
        self.num_emojis = num_emojis
        self.gap = gap
        self.output_width, self.output_height = sizes
        self.output_format = emojis_format

    def generate(self, emojis_on_image_count: int, keyboard_emojis_count: int) -> Captcha:
        captcha_data = self.generator.generate_captcha(emojis_on_image_count, keyboard_emojis_count)

        emojis_data = [self.emojis[emoji] for emoji in captcha_data.emojis_on_image]
        total_image_width = sum(img.width for img in emojis_data)
        total_spacing_width = self.gap * (len(captcha_data.emojis_on_image) - 1)
        total_width_needed = total_image_width + total_spacing_width

        output_image = Image.new(
            self.output_width, self.output_height, Pixel.from_rgb(255, 255, 255)
        )

        x_offset = (self.output_width - total_width_needed) // 2

        for img in emojis_data:
            y_offset = (self.output_height - img.height) // 2
            output_image.paste(x_offset, y_offset, img, None)
            x_offset += img.width + self.gap

        buffer = output_image.encode(self.output_format)

        return Captcha(
            correct_emoji=captcha_data.correct_emoji,
            emojis=captcha_data.keyboard_emojis,
            image=buffer,
        )
